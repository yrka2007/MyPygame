def human_read_format(size):
    val = ['Б', "КБ", "МБ", "ГБ", "ТБ", "ПБ", "ЭБ", "ЗБ", "ЙБ", "РБ", "КВБ", "РОБ"]
    sz = size
    count = 0
    while True:
        sz //= 1024
        if sz == 0:
            break
        count += 1
    return f'{round(size / 1024 ** count)}{val[count]}'



print(human_read_format(9999 ** 9))

