FPS = 50
WIDTH, HEIGHT = 800, 600
tile_width = tile_height = 50